import Home from "./container/Home";

function App() {
  return (
    <div className="container">
      <Home />
    </div>
  );
}

export default App;
