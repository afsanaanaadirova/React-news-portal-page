import React from "react";
import { BrowserRouter as Router, Link, useParams } from "react-router-dom";
import { Route, Routes } from "react-router-dom";
// Params are placeholders in the URL that begin
// with a colon, like the `:id` param defined in
// the route in this example. A similar convention
// is used for matching dynamic segments in other
// popular web frameworks like Rails and Express.

export default function ParamsExample() {
  return (
    <Router>
      <div>
        <h2>Accounts</h2>

        <ul>
          <li>
            <Link to="/netflix">Netflix</Link>
          </li>
          <li>
            <Link to="/zillow-group">Zillow Group</Link>
          </li>
          <li>
            <Link to="/yahoo">Yahoo</Link>
          </li>
          <li>
            <Link to="/modus-create">Modus Create</Link>
          </li>
        </ul>
        <Routes>
          <Route path="/:id" children={<Child />} />
        </Routes>
      </div>
    </Router>
  );
}
   {
     /* <Routes>
        <Route path="/posts">
          <Route index element={<div>Hi go to a post to start posting</div>} />
          <Route path="1" element={<div>First post</div>} />
        </Route>
        <Route path="/cardinfo" element={<CardInfo />} />
        <Route index element={<div>Please Log In</div>} />
      </Routes> */
   }
function Child() {
  // We can use the `useParams` hook here to access
  // the dynamic pieces of the URL.
  let { id } = useParams();

  return (
    <div>
      <h3>ID: {id}</h3>
    </div>
  );
}
