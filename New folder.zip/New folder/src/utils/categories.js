export const categories = [
  { category: "All" },
  { category: "Business" },
  { category: "Sports" },
  { category: "World" },
  { category: "Technology" },
  { category: "Entertainment" },
  { category: "Science" },
];
